""" A Container is an Item that contains Items. """

from durator.world.game.object.type.item import ItemObject


class ContainerObject(ItemObject):
    pass
