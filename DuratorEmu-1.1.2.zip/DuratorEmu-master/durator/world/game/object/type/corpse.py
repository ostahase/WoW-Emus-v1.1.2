""" A Corpse is the cadaver of an Unit, I guess? """

from durator.world.game.object.type.base_object import BaseObject


class Corpse(BaseObject):
    pass
