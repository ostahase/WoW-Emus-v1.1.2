from durator.world.game.object.type.base_object import BaseObject


class DynamicObject(BaseObject):
    pass
