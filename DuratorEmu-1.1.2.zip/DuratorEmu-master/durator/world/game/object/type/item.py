""" An ItemObject is a BaseObject that appears in world and can be interacted
with. """

from durator.world.game.object.type.base_object import BaseObject


class ItemObject(BaseObject):
    pass
